﻿namespace Core.Caching
{
    public enum EDataValidity
    {
        ShortLiving,
        NormalBusiness,
        StaticReference
    }
}