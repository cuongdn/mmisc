
namespace Core.Business.Common
{
    public abstract class ModelBase
    {
        public abstract object IdValue { get; }
    }
}