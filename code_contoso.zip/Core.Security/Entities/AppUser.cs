﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace Core.Security.Entities
{
    public class AppUser : IdentityUser
    {
    }
}