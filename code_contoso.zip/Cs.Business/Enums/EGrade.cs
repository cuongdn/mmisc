﻿
namespace Cs.Business.Enums
{
    public enum EGrade
    {
        A = 4, B = 3, C = 2, D = 1, E = 0
    }
}
