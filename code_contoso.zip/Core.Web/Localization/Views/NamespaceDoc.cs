﻿using System.Runtime.CompilerServices;

namespace Core.Web.Localization.Views
{
    /// <summary>
    /// All classes used to handle view translations
    /// </summary>
    [CompilerGenerated]
    class NamespaceDoc
    {
    }
}
