﻿using System.Runtime.CompilerServices;

namespace Core.Web.Localization.FlatFile
{
    /// <summary>
    /// Stores localization strings in JSON files in App_Data
    /// </summary>
    [CompilerGenerated]
    class NamespaceDoc
    {
    }
}
