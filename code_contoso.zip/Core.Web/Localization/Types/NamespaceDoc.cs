﻿using System.Runtime.CompilerServices;

namespace Core.Web.Localization.Types
{
    /// <summary>
    /// All classes used to handle translations for validation messages and models
    /// </summary>
    [CompilerGenerated]
    class NamespaceDoc
    {
    }
}
