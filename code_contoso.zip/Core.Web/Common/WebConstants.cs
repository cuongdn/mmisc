﻿
namespace Core.Web.Common
{
    public static class WebConstants
    {
        public const string ErrorMessage = "ErrorMessage";
    }
}
